/*
SQLyog Community v8.71 
MySQL - 5.5.30 : Database - pandemic
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`pandemic` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `pandemic`;

/*Table structure for table `addreports` */

DROP TABLE IF EXISTS `addreports`;

CREATE TABLE `addreports` (
  `patient_id` varchar(1000) DEFAULT NULL,
  `Patient_Name` varchar(1000) DEFAULT NULL,
  `Symptoms` varchar(1000) DEFAULT NULL,
  `Result` varchar(1000) DEFAULT NULL,
  `Vaccine` varchar(1000) DEFAULT NULL,
  `medicine` varchar(10000) DEFAULT NULL,
  `Hospital` varchar(1000) DEFAULT NULL,
  `date` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `addreports` */

insert  into `addreports`(`patient_id`,`Patient_Name`,`Symptoms`,`Result`,`Vaccine`,`medicine`,`Hospital`,`date`) values ('pat90  ','patient   ','headach,fever,cold','Positive','co-shield','dola-650',NULL,'2024-08-05 15:09:16'),('pat90  ','patient   ','headach,fever,cold','Positive','co-shield','dola-650','apollo','2024-08-05 15:26:14'),('pat90  ','patient   ','headach,fever,cold','-------','co-shield','dola-650','apollo','2024-08-16 16:10:56');

/*Table structure for table `admin_table` */

DROP TABLE IF EXISTS `admin_table`;

CREATE TABLE `admin_table` (
  `id` int(255) DEFAULT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `admin_table` */

insert  into `admin_table`(`id`,`name`,`password`) values (1223,'admin','admin');

/*Table structure for table `hospital` */

DROP TABLE IF EXISTS `hospital`;

CREATE TABLE `hospital` (
  `hid` varchar(225) NOT NULL,
  `name` varchar(1000) DEFAULT NULL,
  `email` varchar(1000) DEFAULT NULL,
  `password` varchar(1000) DEFAULT NULL,
  `mobile` decimal(65,0) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`hid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hospital` */

insert  into `hospital`(`hid`,`name`,`email`,`password`,`mobile`,`address`,`status`) values ('apollo234','apollo','apollo@gmail.com','apollo@123','9977665544','hyd','Approved'),('deccan620','deccan','deccan@gmail.com','deccan@123','9977665544','hyd','Approved');

/*Table structure for table `hosrequest` */

DROP TABLE IF EXISTS `hosrequest`;

CREATE TABLE `hosrequest` (
  `pid` varchar(1000) DEFAULT NULL,
  `hosptal` varchar(20000) DEFAULT NULL,
  `patient_name` varchar(10000) DEFAULT NULL,
  `mobile` varchar(10000) DEFAULT NULL,
  `Symp` varchar(10000) DEFAULT NULL,
  `from_hosptal` varchar(10000) DEFAULT NULL,
  `status` varchar(100) DEFAULT NULL,
  `Medicine` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `hosrequest` */

insert  into `hosrequest`(`pid`,`hosptal`,`patient_name`,`mobile`,`Symp`,`from_hosptal`,`status`,`Medicine`) values ('pat90 ','apollo','patient ','9977665544 ','headach,fever,cold','fromapollo','Recorde Added','co-shield Taken'),('pat74 ','apollo','patient ','9977665544 ','headach,fever,cold','from apollo','Recorde Added','co-shield Taken'),('pat75 ','apollo','patient ','9977665544 ','headach,fever,cold','from apollo','Recorde Added','co-shield Taken'),('pat75 ','apollo','patient ','9977665544 ','headach,fever,cold','from apollo','pending','pending'),('pat75 ','apollo','patient ','9977665544 ','headach,fever,cold','from apollo','pending','pending');

/*Table structure for table `patient` */

DROP TABLE IF EXISTS `patient`;

CREATE TABLE `patient` (
  `Patient_Id` varchar(1000) DEFAULT NULL,
  `Name` varchar(1000) DEFAULT NULL,
  `mobile` longtext,
  `Gender` varchar(1000) DEFAULT NULL,
  `DOB` varchar(1000) DEFAULT NULL,
  `blood_group` varchar(1000) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `patient_hash` varchar(10000) DEFAULT NULL,
  `private_key` varchar(10000) DEFAULT NULL,
  `public_key` varchar(1000) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `patient` */

insert  into `patient`(`Patient_Id`,`Name`,`mobile`,`Gender`,`DOB`,`blood_group`,`address`,`patient_hash`,`private_key`,`public_key`,`status`) values ('pat75','patient','9977665544','male','2024-08-06','B+','hyd','2295ff7a8bd8b3f2884c6482146e3ded0417f72072c079fbe223e13e83a0388e','b9v6ifjnwpy8f55y','eag3w9escykpjkv6','Admitted');

/*Table structure for table `symp` */

DROP TABLE IF EXISTS `symp`;

CREATE TABLE `symp` (
  `patientid` varchar(1000) DEFAULT NULL,
  `Name` varchar(1000) DEFAULT NULL,
  `mobile` longtext,
  `gender` varchar(10000) DEFAULT NULL,
  `blood_group` varchar(1000) DEFAULT NULL,
  `address` varchar(1000) DEFAULT NULL,
  `Symptoms` varchar(1000) DEFAULT NULL,
  `hospital_name` varchar(1000) DEFAULT NULL,
  `status` varchar(1000) DEFAULT NULL,
  `Symentric_Key` varchar(1000) DEFAULT NULL,
  `join_date` varchar(1000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `symp` */

insert  into `symp`(`patientid`,`Name`,`mobile`,`gender`,`blood_group`,`address`,`Symptoms`,`hospital_name`,`status`,`Symentric_Key`,`join_date`) values ('pat75','patient','9977665544','male','B+','hyd','headach,fever,cold','apollo','|\"uGc?(hk)r(D','wwnuedcb6k0qbm4x','2024-08-16 16:09:57'),('pat75','patient','9977665544','male','B+','hyd','headach,fever,cold','apollo','|\"uGc?(hk)r(D','wwnuedcb6k0qbm4x','2024-08-16 16:09:57');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
