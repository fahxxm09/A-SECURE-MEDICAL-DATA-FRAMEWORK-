package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Hash;

/**
 * Servlet implementation class EnterSymptoms
 */
@WebServlet("/EnterSymptoms")
public class EnterSymptoms extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public EnterSymptoms() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String name=request.getParameter("name");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		String gender=request.getParameter("gender");
		String bgroup=request.getParameter("bgroup");
		String address=request.getParameter("address");
		String symp=request.getParameter("symp");
		String hosp=request.getParameter("hosp");
		
		HttpSession session=request.getSession();
		String patient=(String)session.getAttribute("patient");
		try {
			
			//String symphash=Hash.hashString(symp, "SHA-256");
			Connection con=Database.getConnection();
			String sql="insert into symp values(?,?,?,?,?,?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1, "pending");
			ps.setString(2, name);
			ps.setLong(3, mobile);
			ps.setString(4, gender);
			ps.setString(5, bgroup);
			ps.setString(6, address);
			ps.setString(7, symp);
			ps.setString(8, hosp);
			ps.setString(9, "pending");
			ps.setString(10, "pending");
			ps.setString(11, "pending");
			
			int i=ps.executeUpdate();
			PrintWriter o=response.getWriter();
			if(i>0) {
				o.println("<script type=\"text/javascript\">");
				o.println("alert(' Records sent  Successfully wait for approvement...');");
				o.println("window.location='patienthome.jsp';</script>");
			
			}
			else {
				o.println("<script type=\"text/javascript\">");
				o.println("alert(' some thing error please try again...');");
				o.println("window.location='enterdetails.jsp';</script>");
				
			}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
