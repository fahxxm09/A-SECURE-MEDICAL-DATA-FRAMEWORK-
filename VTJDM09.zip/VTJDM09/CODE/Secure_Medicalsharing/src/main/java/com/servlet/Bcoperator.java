package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Bcoperator
 */
@WebServlet("/Bcoperator")
public class Bcoperator extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Bcoperator() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String id=request.getParameter("name");
		String pass=request.getParameter("pass");
		
		PrintWriter o=response.getWriter();
		
		if(id.equalsIgnoreCase("operator") && pass.equalsIgnoreCase("operator")) {
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Blockchain Operator Logined Successfully...');");
			o.println("window.location='bchome.jsp';</script>");
		}
		else {
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' wrong credentials!...');");
			o.println("window.location='Bcoperator.jsp';</script>");
			
		}
	}

}
