package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CreateAdmin
 */
@WebServlet("/CreateAdmin")
public class CreateAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CreateAdmin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		String pass=request.getParameter("pass");
		
		int id=Integer.parseInt(request.getParameter("id"));
		
		try {
		String sql="insert into admin_table values(?,?,?)";
		Connection con=Database.getConnection();
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.setString(3, pass);
		
		int i=ps.executeUpdate();
		PrintWriter o=response.getWriter();
		if(i>0) {
			
			o.println("<script type=\"text/javascript\">");
			o.println("alert('Admin Registered Successfully....');");
			o.println("window.location='bchome.jsp'</script>");
			
		}else {
			
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Admin registeration failed...');");
			o.println("window.location='createAdmin.jsp';</script>");
		}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
