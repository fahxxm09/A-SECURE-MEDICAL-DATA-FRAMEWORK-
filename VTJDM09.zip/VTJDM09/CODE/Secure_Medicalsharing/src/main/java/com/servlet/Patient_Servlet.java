package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bean.Hash;
import com.bean.Patient;
import com.bean.RandomKeys;

/**
 * Servlet implementation class Patient
 */
@WebServlet("/Patient")
public class Patient_Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Patient_Servlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String name=request.getParameter("name");
		String gender=request.getParameter("Gender");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		String dob=request.getParameter("dob");
		String bgoup=request.getParameter("bgroup");
		String address=request.getParameter("address");
		
	Patient   p=new Patient();
	p.setPatient_name(name);
	p.setMobile(mobile);
	p.setGender(gender);
	p.setDob(dob);
	p.setBgroup(bgoup);
	p.setAddress(address);
	
	
	
	PrintWriter o=response.getWriter();
	
	try {
		String hash=Hash.hashString(name, "SHA-256");
		String pkey=RandomKeys.Randprivatekeys(16);
		String publickey=RandomKeys.publickeys(16);
		int i=Database.patientRegister(p, hash,pkey,publickey);
		if(i>0) {
			
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Patient Registered  Successfully...');");
			o.println("window.location='patient_login.jsp';</script>");
		}
		else {
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Patient registeration failed ...');");
			o.println("window.location='patient.jsp';</script>");
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (NoSuchAlgorithmException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	
	}

}
