package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Hosp_Login
 */
@WebServlet("/Hosp_Login")
public class Hosp_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Hosp_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		String hid=request.getParameter("hosid");
		String name=request.getParameter("name");
		
		HttpSession session=request.getSession();
		session.setAttribute("hid", name);
		try {
		Connection con=Database.getConnection();
		String sql="select * from hospital where hid='"+hid+"' and name='"+name+"'";
		PreparedStatement ps=con.prepareStatement(sql);
		ResultSet rs=ps.executeQuery();
		PrintWriter o=response.getWriter();
		if(rs.next()) {
			o.println("<script type=\"text/javascript\">");
			o.println("alert('Welcome! you  Logined Successfully....');");
			o.println("window.location='hoshome.jsp'</script>");
		}
		else {
			o.println("<script type=\"text/javascript\">");
			o.println("alert('Sorry! your Logined Failed....');");
			o.println("window.location='hos_login.jsp'</script>");
		}
		}catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

}
