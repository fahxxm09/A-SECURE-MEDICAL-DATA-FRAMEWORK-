package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Hospital;
import com.bean.RandomKeys;


/**
 * Servlet implementation class HReg
 */
@WebServlet("/HosReg")
public class HReg extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HReg() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		
		System.out.println("hello");
		String uid=request.getParameter("uid");
		String name=request.getParameter("name");
		String email=request.getParameter("email");
		String password=request.getParameter("password");
		long mobile= Long.parseLong(request.getParameter("mobile")) ;
		
		String place=request.getParameter("address");
		
		
		
		
		int n=3;
		uid=RandomKeys.getuid(n);
		
		Hospital h=new Hospital();
		h.setUid(name+uid);
		h.sethName(name);
		h.setPassword(password);
		h.setHemail(email);
		h.setMobile(mobile);
		h.setAddress(place);
		
		System.out.println("hsjhfsdhfiushi");
		
		
		PrintWriter o=response.getWriter();
		
		try {
			int i=Database.hRegister(h);
			//System.out.println("hsjhfsdhfiushi");
			
			if (i > 0) {
				o.println("<script type=\"text/javascript\">");
				o.println("alert('Hospital Register Successfully...');");
				o.println("window.location='Hospital.jsp';</script>");
			} else {
				o.println("<script type=\"text/javascript\">");
				o.println("alert('Please enter valid Details');");
				o.println("window.location='Hreg.jsp';</script>");
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		
	}

}
