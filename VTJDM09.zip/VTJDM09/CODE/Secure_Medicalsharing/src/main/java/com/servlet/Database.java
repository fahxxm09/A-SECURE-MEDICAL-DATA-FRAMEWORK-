package com.servlet;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.bean.Hospital;
import com.bean.Patient;



public class Database {

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/pandemic", "root", "root");
		return conn;
	}
	
	public static int hRegister(Hospital hos) throws ClassNotFoundException, SQLException {

		Connection conn = Database.getConnection();
		String sql = "insert into Hospital values(?,?,?,?,?,?,?)";

		PreparedStatement ps = conn.prepareStatement(sql);
		ps.setString(1, hos.getUid());
		ps.setString(2, hos.gethName());
		ps.setString(3, hos.getHemail());
		ps.setString(4, hos.getPassword());
		ps.setLong(5, hos.getMobile());
		
		ps.setString(6, hos.getAddress());
		ps.setString(7, "Approved");
		

		int i = ps.executeUpdate();
		return i;

	}
	
	public static int patientRegister(Patient p, String patienthash,String privatekey,String publickey) throws ClassNotFoundException, SQLException {
		Connection con=Database.getConnection();
		String sql="insert into patient values(?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, "pending");
		ps.setString(2, p.getPatient_name());
		ps.setLong(3, p.getMobile());
		ps.setString(4, p.getGender());
		ps.setString(5, p.getDob());
		ps.setString(6, p.getBgroup());
		ps.setString(7, p.getAddress());
		ps.setString(8, patienthash);
		ps.setString(9, privatekey);
		ps.setString(10, publickey);
		ps.setString(11, "pending");
		int i=ps.executeUpdate();
		return i;
	
	}
	public static ResultSet patientLogin(Patient p) throws ClassNotFoundException, SQLException {
		Connection con=Database.getConnection();
		String sql="select * from patient where Name=? and mobile=?";
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1, p.getPatient_name());
		ps.setLong(2, p.getMobile());
		ResultSet rs=ps.executeQuery();
		return rs;
	}
	public static ArrayList<Hospital> Viewhospitalnames() throws Exception
	{
	Connection con=Database.getConnection();
		ArrayList<Hospital> al = new ArrayList<Hospital>();
		PreparedStatement ps = con.prepareStatement("select name from hospital");
		//ps.setString(1, Account_No);
		ResultSet rs = ps.executeQuery();
		while(rs.next()) 
		{
			String hos=rs.getString(1);
			Hospital h = new Hospital();
			h.sethName(hos);
			al.add(h);
		}
		return al;
	}
}
