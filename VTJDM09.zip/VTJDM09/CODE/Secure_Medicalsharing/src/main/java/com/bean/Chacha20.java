package com.bean;
import org.bouncycastle.crypto.StreamCipher;
import org.bouncycastle.crypto.engines.ChaCha20Engine;
import org.bouncycastle.crypto.params.KeyParameter;
import org.bouncycastle.crypto.params.ParametersWithIV;
import org.bouncycastle.util.encoders.Hex;


public class Chacha20 {

	
	private static final String CHARSET = "UTF-8";

    public static void main(String[] args) throws Exception {
        // Sample key and nonce (should be securely generated)
        byte[] key = Hex.decode("00000000000000000000000000000000"); // 256-bit key
        byte[] nonce = Hex.decode("000000000000000000000000"); // 96-bit nonce

        // Text to encrypt
        String plainText = "Hello, ChaCha20!";
        byte[] plainTextBytes = plainText.getBytes(CHARSET);

        // Encrypt
        byte[] encryptedBytes = chacha20Encrypt(key, nonce, plainTextBytes);
        System.out.println("Encrypted: " + Hex.toHexString(encryptedBytes));

        // Decrypt
        byte[] decryptedBytes = chacha20Decrypt(key, nonce, encryptedBytes);
        String decryptedText = new String(decryptedBytes, CHARSET);
        System.out.println("Decrypted: " + decryptedText);
    }

    private static byte[] chacha20Encrypt(byte[] key, byte[] nonce, byte[] input) {
        StreamCipher cipher = new ChaCha20Engine();
        cipher.init(true, new ParametersWithIV(new KeyParameter(key), nonce));
        byte[] output = new byte[input.length];
        cipher.processBytes(input, 0, input.length, output, 0);
        return output;
    }

    private static byte[] chacha20Decrypt(byte[] key, byte[] nonce, byte[] input) {
        StreamCipher cipher = new ChaCha20Engine();
        cipher.init(true, new ParametersWithIV(new KeyParameter(key), nonce));
        byte[] output = new byte[input.length];
        cipher.processBytes(input, 0, input.length, output, 0);
        return output;
    }
}
