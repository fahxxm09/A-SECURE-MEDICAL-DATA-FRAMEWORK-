package com.bean;

public class Hello {

}
