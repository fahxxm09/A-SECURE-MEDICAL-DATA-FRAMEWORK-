package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bean.Patient;

/**
 * Servlet implementation class Patient_Login
 */
@WebServlet("/Patient_Login")
public class Patient_Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Patient_Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String name=request.getParameter("name");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		
		HttpSession session=request.getSession();
		session.setAttribute("patient", name);
	Patient p=new Patient();
	p.setPatient_name(name);
	p.setMobile(mobile);
	PrintWriter o=response.getWriter();
	try {
	ResultSet rs=Database.patientLogin(p);
		if(rs.next()) {
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Patient Logined Successfully...');");
			o.println("window.location='patienthome.jsp';</script>");
		}else {
			o.println("<script type=\"text/javascript\">");
			o.println("alert(' Patient  Logined failed...');");
			o.println("window.location='patient_login.jsp';</script>");
			
		}
	}catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	}

}
